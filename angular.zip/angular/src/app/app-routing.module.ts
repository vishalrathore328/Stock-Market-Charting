import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { AddCompanyComponent } from './components/admin/add-company/add-company.component';
import { UpdateCompanyComponent } from './components/admin/update-company/update-company.component';
import { DeleteCompanyComponent } from './components/admin/delete-company/delete-company.component';
import { AddStockExchangeComponent } from './components/admin/add-stock-exchange/add-stock-exchange.component';
import { ViewStockExchangeComponent } from './components/admin/view-stock-exchange/view-stock-exchange.component';
import { CompanyDataComponent } from './components/user/company-data/company-data.component';
import { ViewIpoComponent } from './components/user/view-ipo/view-ipo.component';
import { ChartsComponent } from './components/user/charts/charts.component';
import { UpdateProfileComponent } from './components/user/update-profile/update-profile.component';
import { UpdateIpoComponent } from './components/admin/update-ipo/update-ipo.component';
import { ImportDataComponent } from './components/admin/import-data/import-data.component';

const routes: Routes = [
  {
    path: '', 
    redirectTo: 'welcome', 
    pathMatch: 'full'
  },
  {
    path: 'welcome',
    component: WelcomeComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'register',
    component: RegisterComponent
  },
  {
    path: 'admin/company/add',
    component: AddCompanyComponent
  },
  {
    path: 'admin/company/update',
    component: UpdateCompanyComponent
  },
  {
    path: 'admin/company/deactivate',
    component: DeleteCompanyComponent
  },
  {
    path: 'admin/stockexchange/add',
    component: AddStockExchangeComponent
  },
  {
    path: 'admin/stockexchange/view',
    component: ViewStockExchangeComponent
  },
  {
    path: 'admin/ipo',
    component: UpdateIpoComponent
  },
  {
    path: 'admin/import',
    component: ImportDataComponent
  },
  {
    path: 'user/company',
    component: CompanyDataComponent
  },
  {
    path: 'user/ipo',
    component: ViewIpoComponent
  },
  {
    path: 'user/charts',
    component: ChartsComponent
  },
  {
    path: 'user/updateprofile',
    component: UpdateProfileComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
