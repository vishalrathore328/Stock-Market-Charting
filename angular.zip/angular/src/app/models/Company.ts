export interface Company{
    companyName: string;
    companyCode: string;
    companyCeo: string;
    directors: string[];
    listedInStockExchange: string[];
    sectorName: string;
    turnover: number;
    about: string;
}