export interface StockExchange{
    stockExchangeName: string;
    brief: string;
    address: string;
    remarks: string;
}