export interface RegistrationModel{
    username: string;
    password: string;
    userType: string;
    email: string;
    mobileNumber: string;
}