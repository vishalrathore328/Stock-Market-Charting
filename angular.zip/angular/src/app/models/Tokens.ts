export interface Tokens{
    jwt: string;
    userType: string;
    refreshToken : string;
}