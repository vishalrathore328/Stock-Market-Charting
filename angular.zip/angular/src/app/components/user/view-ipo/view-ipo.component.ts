import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-ipo',
  templateUrl: './view-ipo.component.html',
  styleUrls: ['./view-ipo.component.css']
})
export class ViewIpoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
