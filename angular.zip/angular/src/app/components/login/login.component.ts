import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';

import { AuthenticationRequest } from '../../models/AuthenticationRequest';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  cardTitle: string = "STOCK MARKET CHARTING APPLICATION";
  authenticationRequest: AuthenticationRequest;
  
  constructor(private loginService: LoginService) {}

  ngOnInit() : void {

  }

  isAdminLoggedIn(): boolean{
    return this.loginService.isAdminLoggedIn();
  }

  isUserLoggedIn(): boolean{
    return this.loginService.isUserLoggedIn();
  }
}
