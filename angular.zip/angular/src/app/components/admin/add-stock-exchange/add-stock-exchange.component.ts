import { Component, OnInit } from '@angular/core';
import { StockExchange } from 'src/app/models/StockExchange';

@Component({
  selector: 'app-add-stock-exchange',
  templateUrl: './add-stock-exchange.component.html',
  styleUrls: ['./add-stock-exchange.component.css']
})
export class AddStockExchangeComponent implements OnInit {

  stockExchange: StockExchange;
  constructor() { }

  ngOnInit(): void {
  }

}
