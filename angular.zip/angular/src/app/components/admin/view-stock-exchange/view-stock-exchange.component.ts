import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-stock-exchange',
  templateUrl: './view-stock-exchange.component.html',
  styleUrls: ['./view-stock-exchange.component.css']
})
export class ViewStockExchangeComponent implements OnInit {

  isFound: boolean;

  constructor() { 
    this.isFound = false;
  }

  ngOnInit(): void {
  }

}
