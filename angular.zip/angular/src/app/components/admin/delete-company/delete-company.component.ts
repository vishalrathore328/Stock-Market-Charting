import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-company',
  templateUrl: './delete-company.component.html',
  styleUrls: ['./delete-company.component.css']
})
export class DeleteCompanyComponent implements OnInit {

  companyName: string;
  
  constructor() { }

  ngOnInit(): void {
  }

}
