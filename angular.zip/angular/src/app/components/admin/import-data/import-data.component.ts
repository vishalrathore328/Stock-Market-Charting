import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-import-data',
  templateUrl: './import-data.component.html',
  styleUrls: ['./import-data.component.css']
})
export class ImportDataComponent implements OnInit {

  fileUploaded: File;  
  
  constructor(private http: HttpClient) { }

  ngOnInit(): void {
  }

  uploadFile(event) {  
    this.fileUploaded = event.target.files[0];  
  }  

  uploadFileToServer(){
    this.http.post<>('', this.fileUploaded);
  }

}
