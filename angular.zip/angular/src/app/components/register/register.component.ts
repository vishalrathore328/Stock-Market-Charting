import { Component, OnInit } from '@angular/core';
import { RegisterService } from 'src/app/services/register.service';
import { RegistrationModel } from 'src/app/models/RegistrationModel';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  cardTitle: string = "STOCK MARKET CHARTING APPLICATION";

  registrationModel: RegistrationModel;

  isEmailSent: boolean = false;
  
  constructor(private registerService: RegisterService) { }

  ngOnInit(): void {
  }

  onClick(){
    if(this.registerService.signUp(this.registrationModel)){
      this.isEmailSent = true;
    }
  }

}
