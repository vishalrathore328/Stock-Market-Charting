import { Injectable } from '@angular/core';

import { RegistrationModel } from 'src/app/models/RegistrationModel';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { config } from '../config';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  constructor(private http: HttpClient, private router: Router) { }

  signUp(registrationModel: RegistrationModel){
    return this.http.post<any>(`${config.apiUrl}/`, registrationModel).subscribe((response) => {
      return null;
    });
  }

}
