import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { LoginComponent } from './components/login/login.component';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { RegisterComponent } from './components/register/register.component';
import { LoginService } from './services/login.service';
import { RegisterService } from './services/register.service';
import { TokenInterceptor } from './interceptor/token.interceptor';
import { ImportDataComponent } from './components/admin/import-data/import-data.component';
import { CompanyDataComponent } from './components/user/company-data/company-data.component';
import { UpdateProfileComponent } from './components/user/update-profile/update-profile.component';
import { ViewIpoComponent } from './components/user/view-ipo/view-ipo.component';
import { ChartsComponent } from './components/user/charts/charts.component';
import { AddCompanyComponent } from './components/admin/add-company/add-company.component';
import { UpdateCompanyComponent } from './components/admin/update-company/update-company.component';
import { DeleteCompanyComponent } from './components/admin/delete-company/delete-company.component';
import { UpdateIpoComponent } from './components/admin/update-ipo/update-ipo.component';
import { AddStockExchangeComponent } from './components/admin/add-stock-exchange/add-stock-exchange.component';
import { ViewStockExchangeComponent } from './components/admin/view-stock-exchange/view-stock-exchange.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    LoginComponent,
    WelcomeComponent,
    RegisterComponent,
    ImportDataComponent,
    CompanyDataComponent,
    UpdateProfileComponent,
    ViewIpoComponent,
    ChartsComponent,
    AddCompanyComponent,
    UpdateCompanyComponent,
    DeleteCompanyComponent,
    UpdateIpoComponent,
    AddStockExchangeComponent,
    ViewStockExchangeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    NgbModule
  ],
  providers: [
    LoginService,
    RegisterService,
    {
      provide : HTTP_INTERCEPTORS,
      useClass : TokenInterceptor,
      multi : true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
